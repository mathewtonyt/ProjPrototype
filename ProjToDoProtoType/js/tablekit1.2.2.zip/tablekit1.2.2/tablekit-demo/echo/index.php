<?php
header('Content-Type: text/plain; charset=UTF-8');
	echo $_POST['value'];
	
?>